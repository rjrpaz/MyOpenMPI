#include "ethertest.h"

void sigint(int signum); 
